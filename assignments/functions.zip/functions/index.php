<html>
<head>
  <title>CME419 | Functions</title>
  <link rel="stylesheet" href="style.css" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
  <?php
    require('area.php'); echo "<br />";
    require('mpg.php'); echo "<br />";
    require('bmi.php'); echo "<br />";
  ?>
</body>
</html>
